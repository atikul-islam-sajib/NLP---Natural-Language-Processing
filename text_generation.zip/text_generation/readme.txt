Run Shakespeare_poetry_generation to train on 250 epochs.
  -It will take some 2 hours to train.

To just load the trained model run shakespeare_poetry_generation-copy1.ipynb

Experiment in Shakespeare_poetry_generationv.1.ipynb

Try running and testing on friends data for fun and share the results :)
